# dshub-hub

The Rust wasm data engine (SSRM **and** CSRM) for AG-Grid, hosted in a **SharedWorker**:
one hub per (origin + appName), one shared cache + upstream feed, an O(1) shared delta,
and a memoized columnar snapshot. Ships as two things:

- **`runtime/`** — static assets served raw, same-origin (the SharedWorker + wasm + STOMP adapter + your config).
- **`lib/`** — the importable client (`useSsrm`, `useCsrm`, adapters, provider).

## Install
```
npm install ./dshub-hub-0.1.0.tgz     # or from your registry
```

## 1. Serve the runtime assets same-origin
Copy them where your app serves static files (Vite `public/`), under a path of your choice:
```
cp -r node_modules/dshub-hub/runtime public/dshub
```
Requirements: served **raw** (not bundler-transformed), `.wasm` as `application/wasm`,
same-origin. No COOP/COEP needed (single-threaded wasm). The worker uses **relative**
imports, so the folder is self-contained and portable.

## 2. Point it at your data
`runtime/positions.config.json` (the `boot_datasource` config: schema, keyColumns,
connection, snapshot/updates) and `runtime/artifact.json` (column list) are examples —
replace them with your datasource. If your upstream isn't STOMP, swap `runtime/stomp.mjs`
for an adapter exposing the same `{ onRows, onState }` surface.

## 3. Use it (React)
```tsx
import { ModuleRegistry } from 'ag-grid-community';
import { AllEnterpriseModule } from 'ag-grid-enterprise';
ModuleRegistry.registerModules([AllEnterpriseModule]);

import { useSsrm, useCsrm, applyCsrmDelta, attachSsrmLiveTicks, buildColDefs } from 'dshub-hub';

const REF = { datasourceId: 'positions', params: { clientId: 'my-app', rate: 2000, batchSize: 10 } };
const HUB = { workerUrl: '/dshub/dshub-rust.worker.js', appId: 'my-app' };

// --- SSRM (windowed, scales to millions) ---
const { wired } = useSsrm(REF, artifact, { ...HUB, searchColumns: ['desk','trader'] });
// onGridReady(e):
//   ssrm.attach(control, e.api, { refreshMs: 200, ref: REF });
//   attachSsrmLiveTicks(e.api, control);   // per-cell + deep-group live ticking
//   <AgGridReact rowModelType="serverSide" serverSideDatasource={ssrm.datasource()}
//                getRowId={(p) => ssrm.getRowId(p)} columnDefs={buildColDefs(artifact, wired.dataService)} />

// --- CSRM (whole dataset in the browser, client-side grouping) ---
const { wired } = useCsrm(REF, artifact, HUB);
// onGridReady(e):
//   const known = new Set(wired.initialRows.map((r) => r.__key));
//   for (const m of wired.stream.buffer) applyCsrmDelta(e.api, m, known);
//   wired.stream.buffer.length = 0;
//   wired.stream.live = (m) => applyCsrmDelta(e.api, m, known);
//   <AgGridReact rowData={wired.initialRows} getRowId={(p) => p.data.__key} grandTotalRow="bottom" />
```

Both hooks talk to the **same** SharedWorker — open many tabs and they share one hub +
cache. A visible page polls at 100ms to keep delivery realtime (SharedWorker timers
throttle to ~1Hz otherwise; the hook handles this).

## Choosing a model
- **SSRM** — ships only the visible window; grouping/agg in the hub; scales to millions of rows and many light clients.
- **CSRM** — loads the whole dataset (~1GB/tab at 20k×372); all grouping/agg client-side; best up to ~tens of thousands of rows.

## Rebuilding the wasm
The engine in `runtime/dshub.js` + `dshub_bg.wasm` is prebuilt. To rebuild from the Rust crate:
```
cargo build --release --target wasm32-unknown-unknown --no-default-features --features wasm
wasm-bindgen target/wasm32-unknown-unknown/release/dshub.wasm --target web --out-dir pkg
```
